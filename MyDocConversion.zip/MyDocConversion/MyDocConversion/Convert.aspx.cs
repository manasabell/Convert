﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Office.Interop.Word;
using System.IO;
using System.Web.Hosting;
using System.Web.UI.HtmlControls;


/// <summary>
/// This is the namespace used to create the desired functionality
/// </summary>
namespace MyDocConversion
{
    /// <summary>
    /// The events and the functions used for the functionality are described
    /// </summary>
    public partial class Convert : System.Web.UI.Page
    {
        /// <summary>
        /// These page level variables help in easy access of the path across the events
        /// </summary>
        string DocPath;
        static string PdfPath;
        static string filename;
        Microsoft.Office.Interop.Word.Application appWord;        
        public Microsoft.Office.Interop.Word.Document wordDocument { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            
            
        }
        
        /// <summary>
        /// This event is fired when the user tries to convert a selected word document into a pdf document.
        /// The word document is opened first and then converted to a pdf document at a specified location.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void BtnConvert_Click(object sender, EventArgs e)
        {

            if (FileSelect.HasFile)
            {
                try
                {
                    filename = Path.GetFileName(FileSelect.FileName);
                    DocPath = FileSelect.PostedFile.FileName;
                    //FileSelect.SaveAs(Server.MapPath("~/") + filename);
                    //path = Server.MapPath("~/") + filename;
                    lblWordConvert.Text = DocPath;//Server.MapPath("~/") + filename;
                    if (filename.Contains(".docx"))
                        filename = filename.Replace(".docx", "");
                    if (filename.Contains(".doc"))
                        filename = filename.Replace(".doc", "");
                    PdfPath = @"C:\Users\traje\source\repos\MyDocConversion\MyDocConversion\Documents\" + filename + ".pdf";
                    // Take a document from the specified and convert to pdf
                    appWord = new Microsoft.Office.Interop.Word.Application();
                    wordDocument = appWord.Documents.Open(DocPath);
                    wordDocument.ExportAsFixedFormat(PdfPath, WdExportFormat.wdExportFormatPDF);
                    lblWordConvert.Text = "PDF Document created";// + PdfPath;
                }
                //To catch any exception and display in a user friendly manner
                catch (Exception ex)
                {
                    lblWordConvert.Text = "The following error occured: " + ex.Message;
                }
            }
            else
                lblWordConvert.Text = "Please select a file.";
            
        }

        /// <summary>
        /// This button click takes in the latest created pdf document from the file path, extracts the contents and 
        /// displays in the web browser
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void BtnExtractPDF_Click(object sender, EventArgs e)
        {
            
            try
            {               
                //Checks if a document has been created
                if (PdfPath.Length > 0)
                {
                    lblPDFExtract.Text = "File Extracted";//PdfPath;
                    myIFrame.Visible = true;                    
                    myIFrame.Attributes.Add("src", @"\Documents\" + filename + ".pdf");

                    //Uri fileUri = new Uri(new Uri("file://"), PdfPath.ToString());
                    //myIFrame.Attributes.Add("src", fileUri.AbsoluteUri);

                    //String encounterID = Request.QueryString["EncounterID"];
                    //myIFrame.Attributes.Add("src", "showpdf.aspx?EncounterID=" + Request.QueryString["EncounterID"]);
                }
                //Displays the message that the document is missing
                else
                {
                    myIFrame.Visible=false;
                    lblPDFExtract.Text = "The file is missing";
                }
            }
            //To catch any exception and display in a user friendly manner
            catch(Exception ex)
            {
                lblPDFExtract.Text = ex.Message;
            }
            
        }
        

        

       
    }



   
}